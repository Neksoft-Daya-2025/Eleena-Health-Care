<?php
/**
 * Class CHT_icons
 *
 * @author  : Premio <contact@premio.io>
 * @license : GPL2
 * */

namespace CHT\includes;
if (defined('ABSPATH') === false) {
    exit;
}

class CHT_Widget
{

    /**
     * The Name of this plugin.
     *
     * @var    string    $pluginSlug    The Slug of this plugin.
     * @since  1.0.0
     * @access public
     */
    protected $pluginSlug = 'chaty-app';

    /**
     * The Slug of this plugin.
     *
     * @var    string    $pluginName    The Name of this plugin.
     * @since  1.0.0
     * @access public
     */
    protected $friendlyName = 'Chaty Widget';

    /**
     * Instance of Class.
     *
     * @var    string    $instance    Instance of Class.
     * @since  1.0.0
     * @access public
     */
    protected static $instance = null;


    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since 1.0.0
     */
    public function __construct()
    {

    }//end __construct()


    /**
     * Get Instanace of Class
     *
     * @since  1.0.0
     * @return $instance
     */
    public static function get_instance()
    {
        // If the single instance hasn't been set, set it now.
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;

    }//end get_instance()


    /**
     * Get Plugin Slug
     *
     * @since  1.0.0
     * @return $pluginSlug
     */
    public function get_pluginSlug()
    {
        return $this->pluginSlug;

    }//end get_pluginSlug()


    /**
     * Get Plugin Name
     *
     * @since  1.0.0
     * @return $friendlyName
     */
    public function get_name()
    {
        return $this->friendlyName;

    }//end get_name()


}//end class
