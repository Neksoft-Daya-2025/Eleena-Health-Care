<?php
/**
 * Class Chaty front end
 *
 * @author  : Premio <contact@premio.io>
 * @license : GPL2
 * */

namespace CHT\frontend;

use CHT\admin\CHT_Admin_Base;
use CHT\admin\CHT_Social_Icons;
use http\Env\Response;

if (defined('ABSPATH') === false) {
    exit;
}

$adminBase = CHT_ADMIN_INC.'/class-admin-base.php';
require_once $adminBase;

$socialIcons = CHT_ADMIN_INC.'/class-social-icons.php';
require_once $socialIcons;

class CHT_Frontend extends CHT_Admin_Base
{

    /**
     * The widget number of settings
     *
     * @var    string    $widgetNumber    The Slug of this plugin.
     * @since  1.0.0
     * @access public
     */
    public $widgetNumber;


    /**
     * CHT_Frontend constructor.
     */
    public function __construct()
    {
        $this->socials = CHT_Social_Icons::get_instance()->get_icons_list();
        if (wp_doing_ajax()) {
            add_action('wp_ajax_choose_social', [$this, 'choose_social_handler']);
            add_action('wp_ajax_get_chaty_settings', [$this, 'get_chaty_settings']);
            // Return setting for a social media in html.
            add_action('wp_ajax_chaty_front_form_save_data', [$this, 'chaty_front_form_save_data']);
            add_action('wp_ajax_nopriv_chaty_front_form_save_data', [$this, 'chaty_front_form_save_data']);

            add_action('wp_ajax_remove_chaty_widget', [$this, 'remove_chaty_widget']);
            // Remove social media widget.
            add_action('wp_ajax_change_chaty_widget_status', [$this, 'change_chaty_widget_status']);
            // Remove social media widget.
        }

        $ctBuilder = filter_input(INPUT_GET, 'ct_builder');
        if ($ctBuilder === null) {
            add_action('wp_enqueue_scripts', [ $this, 'cht_front_end_css_and_js' ], 0);
        }

    }//end __construct()


    /**
     * Removes widget settings
     *
     * @since  1.0.0
     * @access public
     * @return null
     */
    public function remove_chaty_widget()
    {
        if (current_user_can('manage_options')) {
            $widgetIndex = filter_input(INPUT_POST, 'widget_index');
            $widgetNonce = filter_input(INPUT_POST, 'widget_nonce');
            if (isset($widgetIndex) && !empty($widgetIndex) && !empty($widgetNonce) && wp_verify_nonce($widgetNonce, "chaty_remove_".$widgetIndex)) {
                $options = [
                    'mobile'  => '1',
                    'desktop' => '1',
                ];
                delete_option("cht_active");
                delete_option("chaty_icons_view");
                delete_option("chaty_icons_view");
                delete_option("cht_cta_text_color");
                delete_option("cht_cta_bg_color");
                delete_option("cht_pending_messages");
                delete_option("cht_number_of_messages");
                delete_option("cht_number_color");
                delete_option("cht_number_bg_color");
                delete_option("cht_cta_switcher");
                delete_option("chaty_attention_effect");
                delete_option("chaty_default_state");
                delete_option("chaty_trigger_on_time");
                delete_option("chaty_trigger_time");
                delete_option("chaty_trigger_on_exit");
                delete_option("chaty_trigger_on_scroll");
                delete_option("chaty_trigger_on_page_scroll");
                delete_option("cht_close_button");
                delete_option("cht_close_button_text");
                delete_option("chaty_updated_on");

                foreach ($this->socials as $social) {
                    delete_option('cht_social_'.$social['slug']);
                }

                update_option('cht_devices', $options);
                update_option('cht_position', 'right');
                update_option('cht_cta', 'Contact us');
                update_option('cht_numb_slug', ',Phone,Whatsapp');
                update_option('cht_social_whatsapp', '');
                update_option('cht_social_phone', '');
                update_option('cht_widget_size', '54');
                update_option('widget_icon', 'chat-base');
                update_option('cht_widget_img', '');
                update_option('cht_color', '#A886CD');
                echo esc_url(admin_url("admin.php?page=chaty-app"));
                exit;
            }//end if
        }//end if

    }//end remove_chaty_widget()


    /**
     * Updates widgets status
     *
     * @since  1.0.0
     * @access public
     * @return Status
     */
    public function change_chaty_widget_status()
    {
        if (current_user_can('manage_options')) {
            $widgetIndex = filter_input(INPUT_POST, 'widget_index', FILTER_SANITIZE_STRING);
            $widgetNonce = filter_input(INPUT_POST, 'widget_nonce', FILTER_SANITIZE_STRING);
            if (isset($widgetIndex) && !empty($widgetIndex) && !empty($widgetNonce) && wp_verify_nonce($widgetNonce, "chaty_remove_".$widgetIndex)) {
                $widgetIndex = trim($widgetIndex, "_");
                if (empty($widgetIndex) || $widgetIndex == 0) {
                    $widgetIndex = "";
                } else {
                    $widgetIndex = "_".$widgetIndex;
                }

                $status = get_option("cht_active".$widgetIndex);
                if ($status) {
                    update_option("cht_active".$widgetIndex, 0);
                } else {
                    update_option("cht_active".$widgetIndex, 1);
                }
            }
        }

        echo "1";
        exit;

    }//end change_chaty_widget_status()


    /**
     * Save form data submitted by Visitors
     *
     * @since  1.0.0
     * @access public
     * @return $response
     */
    function chaty_front_form_save_data()
    {
        $response = [
            'status'  => 0,
            'error'   => 0,
            'errors'  => [],
            'message' => '',
        ];
        $postData = filter_input_array(INPUT_POST);
        if (isset($postData['nonce']) && isset($postData['widget']) && wp_verify_nonce($postData['nonce'], "chaty-front-form".$postData['widget'])) {
            $name    = isset($postData['name']) ? $postData['name'] : "";
            $phone   = isset($postData['email']) ? $postData['phone'] : "";
            $email   = isset($postData['phone']) ? $postData['email'] : "";
            $message = isset($postData['message']) ? $postData['message'] : "";
            $refURL  = isset($postData['ref_url']) ? $postData['ref_url'] : "";
            $widget  = $postData['widget'];
            $channel = $postData['channel'];

            $value = get_option('cht_social_'.$channel);
            // Get saved settings for button
            $errors = [];
            if (!empty($value)) {
                $fieldSetting = isset($value['name']) ? $value['name'] : [];
                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes" && isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes" && empty($name)) {
                    $error    = [
                        'field'   => 'chaty-field-name',
                        'message' => esc_attr("this field is required", 'chaty'),
                    ];
                    $errors[] = $error;
                }

                $fieldSetting = isset($value['phone']) ? $value['phone'] : [];
                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes" && isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes" && empty($phone)) {
                    $error    = [
                        'field'   => 'chaty-field-phone',
                        'message' => esc_attr("this field is required", 'chaty'),
                    ];
                    $errors[] = $error;
                }

                $fieldSetting = isset($value['email']) ? $value['email'] : [];
                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes" && isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes") {
                    if (empty($email)) {
                        $error    = [
                            'field'   => 'chaty-field-email',
                            'message' => esc_attr("this field is required", 'chaty'),
                        ];
                        $errors[] = $error;
                    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $error    = [
                            'field'   => 'chaty-field-email',
                            'message' => esc_attr("email address is not valid", 'chaty'),
                        ];
                        $errors[] = $error;
                    }
                }

                $fieldSetting = isset($value['message']) ? $value['message'] : [];
                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes" && isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes" && empty($message)) {
                    $error    = [
                        'field'   => 'chaty-field-message',
                        'message' => esc_attr("this field is required", 'chaty'),
                    ];
                    $errors[] = $error;
                }

                if (empty($errors)) {
                    $widget = trim($widget, "_");
                    $response['message']          = esc_attr($value['thanks_message']);
                    $response['redirect_action']  = esc_attr($value['redirect_action']);
                    $response['redirect_link']    = esc_url($value['redirect_link']);
                    $response['link_in_new_tab']  = esc_attr($value['link_in_new_tab']);
                    $response['close_form_after'] = esc_attr($value['close_form_after']);
                    $response['close_form_after_seconds'] = esc_attr($value['close_form_after_seconds']);

                    date_default_timezone_set(get_option('timezone_string'));
                    $currentDate = date("Y-m-d H:i:s");

                    $newDate = get_date_from_gmt($currentDate, "Y-m-d H:i:s");

                    global $wpdb;
                    $chatyTable   = $wpdb->prefix.'chaty_contact_form_leads';
                    $insert       = [];
                    $fieldSetting = isset($value['name']) ? $value['name'] : [];
                    if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                        $insert['name'] = esc_sql(sanitize_text_field($name));
                    }

                    $fieldSetting = isset($value['email']) ? $value['email'] : [];
                    if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                        $insert['email'] = esc_sql(sanitize_text_field($email));
                    }

                    $fieldSetting = isset($value['phone']) ? $value['phone'] : [];
                    if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                        $insert['phone_number'] = esc_sql(sanitize_text_field($phone));
                    }

                    $fieldSetting = isset($value['message']) ? $value['message'] : [];
                    if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                        $insert['message'] = esc_sql(sanitize_text_field($message));
                    }

                    $insert['ref_page']   = esc_url(esc_sql(sanitize_text_field($refURL)));
                    $insert['ip_address'] = esc_url($this->get_user_ipaddress());
                    $insert['widget_id']  = esc_sql(sanitize_text_field($widget));
                    $insert['created_on'] = esc_sql($newDate);
                    $wpdb->insert($chatyTable, $insert);

                    $response['status'] = 1;
                } else {
                    $response['errors'] = $errors;
                    $response['error']  = 1;
                }//end if
            } else {
                $response['message'] = "Invalid request, Please try again";
            }//end if
        } else {
            $response['message'] = "Invalid request, Please try again";
        }//end if

        echo json_encode($response);
        exit;

    }//end chaty_front_form_save_data()


    /**
     * Load JS/CSS for front End
     *
     * @since  1.0.0
     * @access public
     * @return Success
     */
    function cht_front_end_css_and_js()
    {
        if ($this->canInsertWidget()) :
            // Initialize widget if widget is enable for current page.
            $social = $this->get_social_icon_list();
            // Get active icon list.
            $chtActive = get_option("cht_active");

            // Get custom background color for widget.
            $defColor    = get_option('cht_color');
            $customColor = get_option('cht_custom_color');
            // Checking for custom color.
            if (!empty($customColor)) {
                $color = $customColor;
            } else {
                $color = $defColor;
            }

            $bgColor = strtoupper($color);

            $len = count($social);
            // Get total active channels.
            $cta = nl2br(get_option('cht_cta'));
            $cta = str_replace("&amp;#39;", "'", $cta);
            $cta = str_replace("&#39;", "'", $cta);
            $cta = esc_attr__(wp_unslash($cta));
            $cta = html_entity_decode($cta);

            $isPro = get_option('cht_token');
            // Is PRO version.
            $isPro = (empty($isPro) || $isPro == null) ? 0 : 1;

            $positionSide = get_option('positionSide');
            // Get widget position.
            $chtBottomSpacing = get_option('cht_bottom_spacing');
            // Get widget position from bottom.
            $chtSideSpacing = get_option('cht_side_spacing');
            // Get widget position from left/Right.
            $chtWidgetSize = get_option('cht_widget_size');
            // Get widget size.
            $positionSide = empty($positionSide) ? 'right' : $positionSide;
            // Initialize widget position if not exists.
            $chtSideSpacing = ($chtSideSpacing) ? $chtSideSpacing : '25';
            // Initialize widget from left/Right if not exists.
            $chtWidgetSize = ($chtWidgetSize) ? $chtWidgetSize : '54';
            // Initialize widget size if not exists.
            $chtWidgetSize = !is_numeric($chtWidgetSize) ? 54 : $chtWidgetSize;
            $position      = get_option('cht_position');
            $position      = ($position) ? $position : 'right';
            // Initialize widget position if not exists.
            $total            = ($chtSideSpacing + $chtWidgetSize + $chtSideSpacing);
            $chtBottomSpacing = ($chtBottomSpacing) ? $chtBottomSpacing : '25';
            // Initialize widget bottom position if not exists.
            $chtSideSpacing = ($chtSideSpacing) ? $chtSideSpacing : '25';
            // Initialize widget left/Right position if not exists.
            $imageID = "";
            // Initialize default image.
            $analytics = get_option("cht_google_analytics");
            // check for google analytics enable or not.
            $analytics = empty($analytics) ? 0 : $analytics;
            // Initialize google analytics flag to 0 if not data not exists.
            $text = esc_html(get_option("cht_close_button_text"));
            // close button settings.
            $closeText = ($text === false) ? "Hide" : $text;

            $fontFamily = get_option('cht_widget_font');
            if ($fontFamily == "System Stack") {
                $fontFamily = "-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif";
            }

            // add inline css for custom position
            $animationClass = get_option("chaty_attention_effect");
            $animationClass = empty($animationClass) ? "" : $animationClass;

            $timeTrigger = get_option("chaty_trigger_on_time");
            $timeTrigger = empty($timeTrigger) ? "no" : $timeTrigger;

            $triggerTime = get_option("chaty_trigger_time");
            $triggerTime = (empty($triggerTime) || !is_numeric($triggerTime) || $triggerTime < 0) ? "0" : $triggerTime;

            $exitIntent = get_option("chaty_trigger_on_exit");
            $exitIntent = empty($exitIntent) ? "no" : $exitIntent;

            $onPageScroll = get_option("chaty_trigger_on_scroll");
            $onPageScroll = empty($onPageScroll) ? "no" : $onPageScroll;

            $pageScroll = get_option("chaty_trigger_on_page_scroll");
            $pageScroll = (empty($pageScroll) || !is_numeric($pageScroll) || $pageScroll < 0) ? "0" : $pageScroll;

            $state = get_option("chaty_default_state");
            $state = empty($state) ? "click" : $state;

            $hasCloseButton = get_option("cht_close_button");
            $hasCloseButton = empty($hasCloseButton) ? "yes" : $hasCloseButton;

            $displayDays  = get_option("cht_date_and_time_settings");
            $displayRules = [];

            $gmt = "";
            if (!empty($displayDays)) {
                $count = 0;
                foreach ($displayDays as $key => $value) {
                    if ($count == 0) {
                        $gmt = intval($value['gmt']);
                        $count++;
                    }

                    $record         = [];
                    $record['days'] = ($value['days'] - 1);
                    $record['start_time']  = $value['start_time'];
                    $record['start_hours'] = intval(date("G", strtotime(date("Y-m-d ".$value['start_time']))));
                    $record['start_min']   = intval(date("i", strtotime(date("Y-m-d ".$value['start_time']))));
                    $record['end_time']    = $value['end_time'];
                    $record['end_hours']   = intval(date("G", strtotime(date("Y-m-d ".$value['end_time']))));
                    $record['end_min']     = intval(date("i", strtotime(date("Y-m-d ".$value['end_time']))));
                    $displayRules[]        = $record;
                }
            }

            $displayConditions = 0;
            if (!empty($displayRules)) {
                $displayConditions = 1;
            }

            $mode = get_option("chaty_icons_view");
            $mode = empty($mode) ? "vertical" : $mode;

            $pendingMessages = get_option("cht_pending_messages");
            $pendingMessages = ($pendingMessages === false) ? "off" : $pendingMessages;

            $clickSetting = get_option("cht_cta_action");
            $clickSetting = ($clickSetting === false) ? "click" : $clickSetting;

            $chtNumberOfMessages = get_option("cht_number_of_messages");
            $chtNumberOfMessages = ($chtNumberOfMessages === false) ? 0 : $chtNumberOfMessages;

            $numberColor = get_option("cht_number_color");
            $numberColor = ($numberColor === false) ? "#ffffff" : $numberColor;

            $numberBgColor = get_option("cht_number_bg_color");
            $numberBgColor = ($numberBgColor === false) ? "#dd0000" : $numberBgColor;

            $chtCtaTextColor = get_option("cht_cta_text_color");
            $chtCtaTextColor = ($chtCtaTextColor === false) ? "#dd0000" : $chtCtaTextColor;

            $chtCtaBgColor = get_option("cht_cta_bg_color");
            $chtCtaBgColor = ($chtCtaBgColor === false) ? "#ffffff" : $chtCtaBgColor;

            if (empty($chtNumberOfMessages)) {
                $pendingMessages = "off";
            }

            $bgColor = ($bgColor) ? $bgColor : '#A886CD';

            // widget setting array
            $settings          = [];
            $settings['isPRO'] = 0;
            $settings['pending_messages']   = $pendingMessages;
            $settings['cht_cta_bg_color']   = $chtCtaBgColor;
            $settings['cht_cta_text_color'] = $chtCtaTextColor;
            $settings['click_setting']      = $clickSetting;
            $settings['number_of_messages'] = $chtNumberOfMessages;
            $settings['number_color']       = $numberColor;
            $settings['number_bg_color']    = $numberBgColor;
            $settings['position']           = $position;
            ;
            $settings['social']      = $this->get_social_icon_list();
            $settings['pos_side']    = $positionSide;
            $settings['bot']         = $chtBottomSpacing;
            $settings['side']        = $chtSideSpacing;
            $settings['device']      = $this->device();
            $settings['color']       = $bgColor;
            $settings['rgb_color']   = $this->getRGBColor($bgColor);
            $settings['widget_size'] = $chtWidgetSize;
            $settings['widget_type'] = get_option('widget_icon');
            $settings['widget_img']  = $this->getCustomWidgetImg();
            $settings['cta']         = esc_attr($cta);
            $settings['active']      = ($chtActive && $len >= 1) ? 'true' : 'false';
            $settings['close_text']  = $closeText;
            $settings['analytics']   = $analytics;
            $settings['save_user_clicks'] = 0;
            $settings['close_img']        = "";
            $settings['is_mobile']        = (wp_is_mobile()) ? 1 : 0;
            $settings['ajax_url']         = admin_url('admin-ajax.php');
            $settings['animation_class']  = $animationClass;
            $settings['time_trigger']     = $timeTrigger;
            $settings['trigger_time']     = $triggerTime;
            $settings['exit_intent']      = $exitIntent;
            $settings['on_page_scroll']   = $onPageScroll;
            $settings['page_scroll']      = $pageScroll;
            $settings['gmt'] = $gmt;
            $settings['display_conditions'] = $displayConditions;
            $settings['display_rules']      = $displayRules;
            $settings['display_state']      = $state;
            $settings['has_close_button']   = $hasCloseButton;
            $settings['mode']     = $mode;
            $settings['ajax_url'] = admin_url("admin-ajax.php");

            $data = [];
            $data['object_settings'] = $settings;
            $data['ajax_url']        = admin_url("admin-ajax.php");
            ob_start();
            ?>
                <?php if ($position == "left") { ?>
                #wechat-qr-code{left: <?php echo esc_attr($total) ?>px; right:auto;}
                <?php } else if ($position == "right") { ?>
                #wechat-qr-code{right: <?php echo esc_attr($total) ?>px; left:auto;}
                <?php } else if ($position == "custom") { ?>
                    <?php if ($positionSide == "left") { ?>
                #wechat-qr-code{left: <?php echo esc_attr($total) ?>px; right:auto;}
                    <?php } else { ?>
                #wechat-qr-code{right: <?php echo esc_attr($total) ?>px; left:auto;}
                    <?php } ?>
                <?php } ?>
                .chaty-widget-is a{display: block; margin:0; padding:0;border-radius: 50%;-webkit-border-radius: 50%;-moz-border-radius: 50%; }
                .chaty-widget-is svg{margin:0; padding:0;}
                .chaty-main-widget { display: none; }
                .chaty-in-desktop .chaty-main-widget.is-in-desktop { display: block; }
                .chaty-in-mobile .chaty-main-widget.is-in-mobile { display: block; }
                .chaty-widget.hide-widget { display: none !important; }
                .chaty-widget, .chaty-widget .get, .chaty-widget .get a { width: <?php echo esc_attr($chtWidgetSize + 8); ?>px }
                .facustom-icon { width: <?php echo esc_attr($chtWidgetSize); ?>px; line-height: <?php echo esc_attr($chtWidgetSize); ?>px; height: <?php echo esc_attr($chtWidgetSize); ?>px; font-size: <?php echo esc_attr(intval($chtWidgetSize / 2)); ?>px; }
                .chaty-widget-is a { width: <?php echo esc_attr($chtWidgetSize); ?>px; height: <?php echo esc_attr($chtWidgetSize); ?>px; }
                <?php if (!empty($fontFamily)) { ?>
                .chaty-widget { font-family: <?php echo esc_attr($fontFamily) ?>; }
                <?php } ?>
                <?php foreach ($settings['social'] as $social) {
                    if (!empty($social['bg_color']) && $social['bg_color'] != "#ffffff") {
                        ?>
                .facustom-icon.chaty-btn-<?php echo esc_attr($social['social_channel']) ?> {background-color: <?php echo esc_attr($social['bg_color']) ?>}
                .chaty-<?php echo esc_attr($social['social_channel']) ?> .color-element {fill: <?php echo esc_attr($social['bg_color']) ?>; background: <?php echo esc_attr($social['bg_color']) ?>}
                    <?php }
                } ?>
                /*.chaty-widget-i-title.hide-it { display: none !important; }*/
                body div.chaty-widget.hide-widget { display: none !important; }
            <?php
            echo ".i-trigger .chaty-widget-i-title, .chaty-widget-i .chaty-widget-i-title {color:".esc_attr($chtCtaTextColor)." !important; background:".esc_attr($chtCtaBgColor)." !important;}";
            // echo ".i-trigger .chaty-widget-i-title p, .chaty-widget-i.chaty-main-widget .chaty-widget-i-title p {color:".esc_attr($chtCtaTextColor)." !important; background:".esc_attr($chtCtaBgColor)." !important;}";
            echo ".i-trigger .chaty-widget-i-title p, .chaty-widget-i.chaty-main-widget .chaty-widget-i-title p {color:".esc_attr($chtCtaTextColor)." !important; }";
            echo ".i-trigger .chaty-widget-i:not(.no-tooltip):before, .chaty-widget-i.chaty-main-widget:before { border-color: transparent transparent transparent ".esc_attr($chtCtaBgColor)." !important;}";
            echo ".chaty-widget.chaty-widget-is-right .i-trigger .i-trigger-open.chaty-widget-i:before, .chaty-widget.chaty-widget-is-right .chaty-widget-i:before { border-color: transparent ".esc_attr($chtCtaBgColor)." transparent transparent !important;}";
            echo ".chaty-widget.chaty-widget-is-right .i-trigger .chaty-widget-i:before, .chaty-widget.chaty-widget-is-right .chaty-widget-i:before {border-color: transparent ".esc_attr($chtCtaBgColor)." transparent transparent !important; }";
            $chatyCSS = ob_get_clean();

            if ($len >= 1 && !empty($settings['social'])) {
                $chatyUpdatedOn = get_option("chaty_updated_on");
                if (empty($chatyUpdatedOn)) {
                    $chatyUpdatedOn = time();
                }

                // add js for front end widget
                if (!empty($fontFamily)) {
                    if (!in_array($fontFamily, ["Arial", "Tahoma", "Verdana", "Helvetica", "Times New Roman", "Trebuchet MS", "Georgia", "System Stack", "-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif"])) {
                        wp_enqueue_style('custom-google-fonts', '//fonts.googleapis.com/css?family='.urlencode($fontFamily), false, false);
                    }
                }

                // WP change this
                wp_enqueue_style('chaty-front-css', CHT_PLUGIN_URL."css/chaty-front.min.css", [], $chatyUpdatedOn);
                wp_add_inline_style('chaty-front-css', $chatyCSS);
                wp_enqueue_script("chaty-front-end", CHT_PLUGIN_URL."js/cht-front-script.min.js", [ 'jquery' ], $chatyUpdatedOn, false);
                wp_localize_script('chaty-front-end', 'chaty_settings',  $data);
            }//end if
        endif;

    }//end cht_front_end_css_and_js()


    /**
     * Get Chaty Channel Settings
     *
     * @since  1.0.0
     * @return $data
     */
    public function get_chaty_settings()
    {
        $slug    = filter_input(INPUT_POST, 'social');
        $channel = filter_input(INPUT_POST, 'channel');
        $status  = 0;
        $data    = [];
        if (!empty($slug)) {
            foreach ($this->socials as $social) {
                if ($social['slug'] == $slug) {
                    break;
                }
            }

            if (!empty($social)) {
                $status       = 1;
                $data         = $social;
                $data['help'] = "";
                $data['help_text'] = "";
                $data['help_link'] = "";
                if ((isset($social['help']) && !empty($social['help'])) || isset($social['help_link'])) {
                    $data['help_title'] = isset($social['help_title']) ? $social['help_title'] : "Doesn't work?";
                    $data['help_text']  = isset($social['help']) ? $social['help'] : "";
                    if (isset($data['help_link']) && !empty($data['help_link'])) {
                        $data['help_link'] = $data['help_link'];
                    } else {
                        $data['help_title'] = $data['help_title'];
                    }
                }
            }
        }//end if

        $response            = [];
        $response['data']    = $data;
        $response['status']  = $status;
        $response['channel'] = $channel;
        echo json_encode($response);
        die;

    }//end get_chaty_settings()


    /**
     * Get Chaty Channel Setting
     *
     * @since  1.0.0
     * @return $data
     */
    public function choose_social_handler()
    {
        check_ajax_referer('cht_nonce_ajax', 'nonce_code');
        $slug = filter_input(INPUT_POST, 'social');

        if (!is_null($slug) && !empty($slug)) {
            foreach ($this->socials as $social) {
                if ($social['slug'] == $slug) {
                    break;
                }
            }

            if (!$social) {
                return;
                // Return if social media setting not found.
            }

            ob_start();
            include CHT_DIR."/views/admin/channel.php";
            $html = ob_get_clean();
            echo json_encode($html);
        }//end if

        wp_die();

    }//end choose_social_handler()


    /**
     * Get Social Icon List
     *
     * @since  1.0.0
     * @return $social
     */
    public function get_social_icon_list()
    {
        $social = get_option('cht_numb_slug'.$this->widgetNumber);
        // Get saved social media list
        $social = explode(",", $social);

        $arr = [];
        foreach ($social as $keySoc) :
            foreach ($this->socials as $key => $social) :
                // compare with Default Social media list
                if ($social['slug'] != $keySoc) {
                    continue;
                    // return if slug is not equal
                }

                $value = get_option('cht_social'.$this->widgetNumber.'_'.$social['slug']);
                // Get saved settings for button
                if ($value) {
                    $slug      = strtolower($social['slug']);
                    $channelId = "cht-channel-0";
                    $channelId = trim($channelId, "_");
                    if (!empty($value['value']) || $slug == "contact_us") {
                        $slug          = strtolower($social['slug']);
                        $url           = "";
                        $mobileURL     = "";
                        $desktopTarget = "";
                        $mobileTarget  = "";
                        $qrCodeImage   = "";

                        $channelType = $slug;

                        if (!isset($value['value'])) {
                            $value['value'] = "";
                        }

                        $svgIcon = $social['svg'];
                        if ($slug == "link" || $slug == "custom_link" || $slug == "custom_link_3" || $slug == "custom_link_4" || $slug == "custom_link_5") {
                            if (isset($value['channel_type']) && !empty($value['channel_type'])) {
                                $channelType = $value['channel_type'];

                                foreach ($this->socials as $icon) {
                                    if ($icon['slug'] == $channelType) {
                                        $svgIcon = $icon['svg'];
                                    }
                                }
                            }
                        }

                        $channelType = strtolower($channelType);

                        $val = "";
                        if ($channelType == "viber") {
                            // Viber change to exclude + from number for desktop
                            $val = esc_attr($value['value']);
                            if (is_numeric($val)) {
                                $fc = substr($val, 0, 1);
                                if ($fc == "+") {
                                    $length = (-1 * (strlen($val) - 1));
                                    $val    = substr($val, $length);
                                }

                                if (!wp_is_mobile()) {
                                    // Viber change to include + from number for mobile
                                    $val = "+".$val;
                                }
                            }
                        } else if ($channelType == "whatsapp") {
                            // Whatspp change to exclude + from phone number
                            $val = esc_attr($value['value']);
                            $val = str_replace("+", "", $val);
                            $val = str_replace("-", "", $val);
                            $val = str_replace(" ", "", $val);
                        } else if ($channelType == "facebook_messenger") {
                            // Facebook change to change URL from facebook.com to m.me version 2.1.0 change
                            $val = esc_attr($value['value']);
                            $val = str_replace("facebook.com", "m.me", $val);
                            // Replace facebook.com with m.me version 2.0.1 change
                            $val = str_replace("www.", "", $val);
                            // Replace www. with blank version 2.0.1 change
                            $value['value'] = $val;

                            $val       = trim($val, "/");
                            $valArray  = explode("/", $val);
                            $total     = (count($valArray) - 1);
                            $lastValue = $valArray[$total];
                            $lastValue = explode("-", $lastValue);
                            $totalText = (count($lastValue) - 1);
                            $totalText = $lastValue[$totalText];

                            if (is_numeric($totalText)) {
                                $valArray[$total] = $totalText;
                                $val = implode("/", $valArray);
                            }
                        } else {
                            $val = $value['value'];
                        }//end if

                        if (!isset($value['title'])) {
                            $value['title'] = $social['title'];
                            // Initialize title with default title if not exists. version 2.1.0 change
                        }

                        $imageURL       = "";
                        $val            = esc_attr($val);
                        $value['title'] = esc_attr($value['title']);

                        // Get custom image URL if uploaded. version 2.1.0 change
                        if (isset($value['image_id']) && !empty($value['image_id'])) {
                            $imageID = $value['image_id'];
                            if (!empty($imageID)) {
                                $imageData = wp_get_attachment_image_src($imageID, "full");
                                if (!empty($imageData) && is_array($imageData)) {
                                    $imageURL = $imageData[0];
                                }
                            }
                        }

                        $onClickFn       = "";
                        $popupHTML       = "";
                        $hasCustomPopup  = 0;
                        $isDefaultOpen   = 0;
                        $embeddedMessage = "";
                        $preSetMessage   = "";
                        $useWhatsappWeb  = 1;
                        $formSettings    = [];
                        // Get custom icon background color if exists. version 2.1.0 change
                        if (!isset($value['bg_color']) || empty($value['bg_color'])) {
                            $value['bg_color'] = '';
                        }

                        if ($channelType == "whatsapp") {
                            // setting for Whatsapp URL
                            $val = str_replace("+", "", $val);
                            if (isset($value['use_whatsapp_web']) && $value['use_whatsapp_web'] == "no") {
                                $url = "https://wa.me/".$val;
                            } else {
                                $url = "https://web.whatsapp.com/send?phone=".$val;
                            }

                            $mobileURL = "https://wa.me/".$val;
                            // https://wa.me/$number?text=$test
                            if (isset($value['pre_set_message']) && !empty($value['pre_set_message'])) {
                                if (isset($value['use_whatsapp_web']) && $value['use_whatsapp_web'] == "no") {
                                    $url .= "?text=".rawurlencode($value['pre_set_message']);
                                } else {
                                    $url .= "&text=".rawurlencode($value['pre_set_message']);
                                }

                                $mobileURL .= "?text=".rawurlencode($value['pre_set_message']);
                            }

                            $url = esc_url($url);
                            if (wp_is_mobile()) {
                                $mobileTarget = "";
                            } else {
                                $desktopTarget = "_blank";
                            }

                            if (isset($value['embedded_window']) && $value['embedded_window'] == "yes") {
                                $embeddedMessage = isset($value['embedded_message']) ? $value['embedded_message'] : "";
                                $preSetMessage   = isset($value['pre_set_message']) ? $value['pre_set_message'] : "";
                                $isDefaultOpen   = (isset($value['is_default_open'])&&$value['is_default_open'] == "yes") ? 1 : 0;
                                $preSetMessage   = esc_attr($preSetMessage);
                                $allowed_html    = [
                                    'a'      => [
                                        'href'  => [],
                                        'title' => [],
                                    ],
                                    'p'      => [],
                                    'br'     => [],
                                    'em'     => [],
                                    'strong' => [],
                                ];
                                $embeddedMessage = wp_kses($embeddedMessage, $allowed_html);

                                $hasCustomPopup = 1;
                                $mobileURL      = "javascript:;";
                                $url            = "javascript:;";
                                $close_button   = "<div role='button' class='close-chaty-popup is-whatsapp-btn'><div class='chaty-close-button'></div></div>";
                                $popupHTML      = "<div class='chaty-whatsapp-popup' data-channel='".$social['slug']."'>";
                                $popupHTML     .= "<div class='default-value' style='display:none'></div>";
                                $popupHTML     .= "<div class='default-msg-value' style='display:none'></div>";
                                $popupHTML     .= "<div class='default-msg-phone' style='display:none'></div>";
                                $popupHTML     .= "<div class='chaty-whatsapp-body'>".$close_button."<div class='chaty-whatsapp-message'></div></div>";
                                $popupHTML     .= "<div class='chaty-whatsapp-footer'>";
                                if (isset($value['use_whatsapp_web']) && $value['use_whatsapp_web'] == "no") {
                                    $useWhatsappWeb = 0;
                                }

                                $popupHTML .= "<form class='whatsapp-chaty-form' autocomplete='off' target='_blank' action='https://web.whatsapp.com/send' method='get'>";
                                $popupHTML .= "<div class='chaty-whatsapp-field'><input autocomplete='off' class='chaty-whatsapp-msg' name='text' value='' /></div>";
                                $popupHTML .= "<input type='hidden' name='phone' class='chaty-whatsapp-phone' value='' />";
                                $popupHTML .= "<input type='hidden' class='is-default-open' value='".esc_html($isDefaultOpen)."' />";
                                $popupHTML .= "<input type='hidden' class='channel-id' value='".esc_html($channelId)."' />";
                                $popupHTML .= "<button type='submit' class='chaty-whatsapp-submit-btn'><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24'><path fill='#ffffff' d='M1.101 21.757L23.8 12.028 1.101 2.3l.011 7.912 13.623 1.816-13.623 1.817-.011 7.912z'></path></svg></button><div style='clear:both'></div>";
                                $popupHTML .= "</form>";
                                $popupHTML .= "</div>";
                                $popupHTML .= "</div>";
                            }//end if
                        } else if ($channelType == "phone") {
                            // setting for Phone
                            $url = "tel:".esc_attr($val);
                        } else if ($channelType == "sms") {
                            // setting for SMS
                            $url = "sms:".esc_attr($val);
                        } else if ($channelType == "telegram") {
                            // setting for Telegram
                            $val           = ltrim($val, "@");
                            $url           = "https://telegram.me/".$val;
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "line" || $channelType == "google_maps" || $channelType == "poptin" || $channelType == "waze") {
                            // setting for Line, Google Map, Link, Poptin, Waze, Custom Link
                            $url           = esc_url($val);
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                        } else if ($channelType == "link" || $channelType == "custom_link" || $channelType == "custom_link_3" || $channelType == "custom_link_4" || $channelType == "custom_link_5") {
                            $is_exist = strpos($val, "javascript");
                            $is_viber = strpos($val, "viber");
                            if ($is_viber !== false) {
                                $url = $val;
                            } else if ($is_exist === false) {
                                $url = esc_url($val);
                                if ($channelType == "custom_link" || $channelType == "link" || $channelType == "custom_link_3" || $channelType == "custom_link_4" || $channelType == "custom_link_5") {
                                    $desktopTarget = (isset($value['new_window']) && $value['new_window'] == 0) ? "" : "_blank";
                                    $mobileTarget  = (isset($value['new_window']) && $value['new_window'] == 0) ? "" : "_blank";
                                }
                            } else {
                                $url       = "javascript:;";
                                $onClickFn = str_replace('"', "'", $val);
                            }
                        } else if ($channelType == "wechat") {
                            // setting for WeChat
                            $url = "javascript:;";
                            if (!empty($value['title'])) {
                                $value['title'] .= ": ".$val;
                            } else {
                                $value['title'] = $val;
                            }

                            $qr_code = isset($value['qr_code']) ? $value['qr_code'] : "";
                            if (!empty($qr_code)) {
                                $imageData = wp_get_attachment_image_src($qr_code, "full");
                                if (!empty($imageData) && is_array($imageData)) {
                                    $qrCodeImage = $imageData[0];
                                }
                            }
                        } else if ($channelType == "viber") {
                            // setting for Viber
                            $url = $val;
                        } else if ($channelType == "snapchat") {
                            // setting for SnapChat
                            $url           = "https://www.snapchat.com/add/".$val;
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "waze") {
                            // setting for Waze
                            $url = "javascript:;";
                            $value['title'] .= ": ".esc_attr($val);
                        } else if ($channelType == "vkontakte") {
                            // setting for vkontakte
                            $url           = "https://vk.me/".esc_attr($val);
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "skype") {
                            // setting for Skype
                            $url = "skype:".esc_attr($val)."?chat";
                        } else if ($channelType == "email") {
                            // setting for Email
                            $url         = "mailto:".$val;
                            $mailSubject = (isset($value['mail_subject']) && !empty($value['mail_subject'])) ? $value['mail_subject'] : "";
                            if ($mailSubject != "") {
                                $url .= "?subject=".esc_attr(urlencode($mailSubject));
                            }

                            $url = esc_url($url);
                        } else if ($channelType == "facebook_messenger") {
                            // setting for facebook URL
                            $url = $val;
                            $url = str_replace("http:", "https:", $url);
                            if (wp_is_mobile()) {
                                $mobileTarget = "";
                            } else {
                                $desktopTarget = "_blank";
                            }

                            $url = esc_url($url);
                        } else if ($channelType == "twitter") {
                            // setting for Twitter
                            $url           = "https://twitter.com/".$val;
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "instagram") {
                            // setting for Instagram
                            $url           = "https://www.instagram.com/".$val;
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "linkedin") {
                            // setting for Linkedin
                            $link_type = !isset($value['link_type']) || $value['link_type'] == "company" ? "company" : "personal";
                            if ($link_type == "personal") {
                                $url = "https://www.linkedin.com/in/".$val;
                            } else {
                                $url = "https://www.linkedin.com/company/".$val;
                            }

                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                            $url           = esc_url($url);
                        } else if ($channelType == "slack") {
                            // setting for slack
                            $url           = esc_url($val);
                            $desktopTarget = "_blank";
                            $mobileTarget  = "_blank";
                        } else if ($channelType == "contact_us") {
                            $url           = "javascript:;";
                            $desktopTarget = "";
                            $mobileTarget  = "";
                            $input_fields  = "";
                            $fields        = [];
                            if (isset($value['name']) || isset($value['email']) || isset($value['message'])) {
                                $fieldSetting = $value['name'];
                                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                                    $is_required = (isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes") ? "is-required" : "";
                                    $placeholder = isset($fieldSetting['placeholder']) ? $fieldSetting['placeholder'] : "Enter your email name";
                                    $field       = [];
                                    $field['is_required'] = $is_required;
                                    $field['placeholder'] = esc_attr($placeholder);
                                    $field['name']        = 'name';
                                    $field['type']        = 'text';
                                    $fields[] = $field;
                                }

                                $fieldSetting = $value['email'];
                                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                                    $is_required = (isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes") ? "is-required" : "";
                                    $placeholder = isset($fieldSetting['placeholder']) ? $fieldSetting['placeholder'] : "Enter your email address";
                                    $field       = [];
                                    $field['is_required'] = $is_required;
                                    $field['placeholder'] = esc_attr($placeholder);
                                    $field['name']        = 'email';
                                    $field['type']        = 'email';
                                    $fields[] = $field;
                                }

                                $fieldSetting = $value['phone'];
                                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                                    $is_required = (isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes") ? "is-required" : "";
                                    $placeholder = isset($fieldSetting['placeholder']) ? $fieldSetting['placeholder'] : "Enter your phone number";
                                    $field       = [];
                                    $field['is_required'] = $is_required;
                                    $field['placeholder'] = esc_attr($placeholder);
                                    $field['name']        = 'phone';
                                    $field['type']        = 'text';
                                    $fields[] = $field;
                                }

                                $fieldSetting = $value['message'];
                                if (isset($fieldSetting['is_active']) && $fieldSetting['is_active'] == "yes") {
                                    $is_required = (isset($fieldSetting['is_required']) && $fieldSetting['is_required'] == "yes") ? "is-required" : "";
                                    $placeholder = isset($fieldSetting['placeholder']) ? $fieldSetting['placeholder'] : "Enter your message";
                                    $field       = [];
                                    $field['is_required'] = $is_required;
                                    $field['placeholder'] = esc_attr($placeholder);
                                    $field['name']        = 'message';
                                    $field['type']        = 'textarea';
                                    $fields[] = $field;
                                }
                            }//end if

                            if (!empty($fields)) {
                                $hasCustomPopup   = 1;
                                $buttonText       = isset($value['button_text']) && !empty($value['button_text']) ? esc_attr($value['button_text']) : "Submit";
                                $buttonBgColor    = isset($value['button_bg_color']) && !empty($value['button_bg_color']) ? esc_attr($value['button_bg_color']) : "#A886CD";
                                $buttonTextColor  = isset($value['button_text_color']) && !empty($value['button_text_color']) ? esc_attr($value['button_text_color']) : "#ffffff";
                                $contactFormTitle = isset($value['contact_form_title']) ? $value['contact_form_title'] : "";
                                $popupHTML        = "<div class='chaty-contact-form' data-channel='".esc_attr($social['slug'])."'>";
                                $popupHTML       .= "<form action='#' method='post' class='chaty-contact-form-data' autocomplete='off'>";
                                $popupHTML       .= "<div class='chaty-contact-header'><div class='chaty-contact-title'></div><div role='button' class='close-chaty-popup'><div class='chaty-close-button'></div></div><div style='clear:both'></div></div>";
                                $popupHTML       .= "<div class='chaty-contact-body'>";
                                $popupHTML       .= "<div class='chaty-contact-fields'>";
                                $popupHTML       .= "</div>";
                                $popupHTML       .= "<input type='hidden' class='chaty-field-widget' name='widget_id' value='' />";
                                $popupHTML       .= "<input type='hidden' class='chaty-field-channel' name='channel' value='{$social['slug']}' />";
                                $nonce            = wp_create_nonce("chaty-front-form");
                                $popupHTML       .= "<input type='hidden' class='chaty-field-nonce' name='nonce' value='{$nonce}' />";
                                $popupHTML       .= "</div>";
                                $popupHTML       .= "<div class='chaty-contact-footer'>";
                                $popupHTML       .= "<button type='submit' class='chaty-contact-submit-btn'></div>";
                                $popupHTML       .= "</div>";
                                $popupHTML       .= "</form>";
                                $popupHTML       .= "</div>";

                                $formSettings['button_text']        = esc_attr($buttonText);
                                $formSettings['button_text_color']  = esc_attr($buttonTextColor);
                                $formSettings['button_bg_color']    = esc_attr($buttonBgColor);
                                $formSettings['contact_form_title'] = esc_attr($contactFormTitle);
                                $formSettings['fields'] = $fields;
                            }//end if
                        } else if ($channelType == "tiktok") {
                            $val            = $value['value'];
                            $firstCharacter = substr($val, 0, 1);
                            if ($firstCharacter != "@") {
                                $val = "@".$val;
                            }

                            $url           = esc_url("https://www.tiktok.com/".$val);
                            $desktopTarget = $mobileTarget = "_blank";
                        }//end if

                        // Instagram checking for custom color
                        if ($channelType == "instagram" && $value['bg_color'] == "#ffffff") {
                            $value['bg_color'] = "";
                        }

                        $svg = trim(preg_replace('/\s\s+/', '', $svgIcon));

                        $isMobile  = isset($value['is_mobile']) ? 1 : 0;
                        $isDesktop = isset($value['is_desktop']) ? 1 : 0;

                        if (empty($mobileURL)) {
                            $mobileURL = $url;
                        }

                        $svgClass = ($channelType == "contact_us") ? "color-element" : "";

                        $svg = '<svg class="ico_d '.$svgClass.'" width="39" height="39" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);">'.$svg.'</svg>';

                        $rgbColor = $this->getRGBColor($value['bg_color']);

                        $data  = [
                            'val'              => esc_attr__(wp_unslash($val)),
                            'default_icon'     => $svg,
                            'bg_color'         => $value['bg_color'],
                            'rbg_color'        => $rgbColor,
                            'title'            => esc_attr__(wp_unslash($value['title'])),
                            'img_url'          => esc_url($imageURL),
                            'social_channel'   => $slug,
                            'channel_type'     => $channelType,
                            'href_url'         => $url,
                            'desktop_target'   => $desktopTarget,
                            'mobile_target'    => $mobileTarget,
                            'qr_code_image'    => esc_url($qrCodeImage),
                            'channel'          => $social['slug'],
                            'is_mobile'        => $isMobile,
                            'is_desktop'       => $isDesktop,
                            'mobile_url'       => $mobileURL,
                            'on_click'         => $onClickFn,
                            "has_font"         => 0,
                            "popup_html"       => $popupHTML,
                            "has_custom_popup" => $hasCustomPopup,
                            "is_default_open"  => $isDefaultOpen,
                            "embedded_message" => $embeddedMessage,
                            "pre_set_message"  => $preSetMessage,
                            "use_whatsapp_web" => $useWhatsappWeb,
                            "form_settings"    => $formSettings,
                        ];
                        $arr[] = $data;
                    }//end if
                }//end if
            endforeach;
        endforeach;
        return $arr;

    }//end get_social_icon_list()


    /**
     * Returns color in RGB format
     *
     * @since  1.0.0
     * @return $string
     */
    public function getRGBColor($color)
    {
        if (!empty($color)) {
            if (strpos($color, '#') !== false) {
                $color = $this->hex2rgba($color);
            }

            if (strpos($color, 'rgba(') !== false || strpos($color, 'rgb(') !== false) {
                $color   = explode(",", $color);
                $color   = str_replace(["rgba(", "rgb(", ")"], ["", "", ""], $color);
                $string  = "";
                $string .= ((isset($color[0])) ? trim($color[0]) : "0").",";
                $string .= ((isset($color[1])) ? trim($color[1]) : "0").",";
                $string .= ((isset($color[2])) ? trim($color[2]) : "0");
                return $string;
            }
        }

        return "0,0,0";

    }//end getRGBColor()


    /**
     * Converts HEX code to RGB
     *
     * @since  1.0.0
     * @return $color
     */
    public function hex2rgba($color, $opacity=false)
    {

        $default = 'rgb(0,0,0)';

        // Return default if no color provided
        if (empty($color)) {
            return $default;
        }

        // Sanitize $color if "#" is provided
        if ($color[0] == '#') {
            $color = substr($color, 1);
        }

        // Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
            $hex = [
                $color[0].$color[1],
                $color[2].$color[3],
                $color[4].$color[5],
            ];
        } else if (strlen($color) == 3) {
            $hex = [
                $color[0].$color[0],
                $color[1].$color[1],
                $color[2].$color[2],
            ];
        } else {
            return $default;
        }

        // Convert hexadec to rgb
        $rgb = array_map('hexdec', $hex);

        // Check if opacity is set(rgba or rgb)
        if ($opacity) {
            if (abs($opacity) > 1) {
                $opacity = 1.0;
            }

            $output = 'rgba('.implode(",", $rgb).','.$opacity.')';
        } else {
            $output = 'rgb('.implode(",", $rgb).')';
        }

        // Return rgb(a) color string
        return $output;

    }//end hex2rgba()


    /**
     * Checking widget is active or not
     *
     * @since  1.0.0
     * @return $chtActive
     */
    private function canInsertWidget()
    {
        return get_option('cht_active') && $this->checkChannels();

    }//end canInsertWidget()


    /**
     * Checking for active channels
     *
     * @since  1.0.0
     * @return $channels
     */
    private function checkChannels()
    {
        $social = explode(",", get_option('cht_numb_slug'));
        $res    = false;
        foreach ($social as $name) {
            $value = get_option('cht_social_'.strtolower($name));
            $res   = $res || !empty($value['value']) || ($name == "Contact_Us");
        }

        return $res;

    }//end checkChannels()


    /**
     * Returns user's IP Address
     *
     * @since  1.0.0
     * @return $ip
     */
    function get_user_ipaddress()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CLIENT_IP']));
        } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // ip pass from proxy
            $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR']));
        } else {
            $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
        }

        return $ip;

    }//end get_user_ipaddress()


}//end class


return new CHT_Frontend();
